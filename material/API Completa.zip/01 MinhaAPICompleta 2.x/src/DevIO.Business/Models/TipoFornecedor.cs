﻿namespace DevIO.Business.Models
{
    public enum TipoFornecedor
    {
        PessoaFisica = 1,
        PessoaJuridica
    }
}