﻿namespace DesignPatterns.FactoryMethod
{
    public enum DataBase
    {
        SqlServer,
        Oracle
    }
}