﻿namespace DesignPatterns
{
    public interface IPagamentoTransferenciaFacade
    {
        string RealizarTransferencia();
    }
}