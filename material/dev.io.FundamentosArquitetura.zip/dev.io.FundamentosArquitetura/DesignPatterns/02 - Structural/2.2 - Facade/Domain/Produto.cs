﻿namespace DesignPatterns
{
    public class Produto    
    {
        public string Nome { get; set; }
        public decimal Valor { get; set; }
    }
}