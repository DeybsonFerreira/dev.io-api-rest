﻿namespace DesignPatterns
{
    public enum MeioPagamento
    {
        CartaoCredito,
        Boleto,
        TransferenciaBancaria
    }
}