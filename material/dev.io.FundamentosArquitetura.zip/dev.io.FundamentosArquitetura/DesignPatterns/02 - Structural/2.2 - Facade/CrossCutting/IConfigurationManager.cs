﻿namespace DesignPatterns
{
    public interface IConfigurationManager
    {
        string GetValue(string node);
    }
}