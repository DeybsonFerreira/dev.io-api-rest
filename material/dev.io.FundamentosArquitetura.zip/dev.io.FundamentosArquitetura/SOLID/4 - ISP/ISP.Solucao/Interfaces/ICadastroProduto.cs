namespace SOLID.ISP.Solucao.Interfaces
{
    public interface ICadastroProduto : ICadastro
    {
        void ValidarDados();
    }
}