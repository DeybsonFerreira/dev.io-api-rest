using SOLID.DIP.Solucao.Interfaces;

namespace SOLID.DIP.Solucao
{
    public class ClienteRepository2 : IClienteRepository
    {
        public void AdicionarCliente(Cliente cliente)
        {

            // Usar outra forma de ir at� o BD

        }
    }
}