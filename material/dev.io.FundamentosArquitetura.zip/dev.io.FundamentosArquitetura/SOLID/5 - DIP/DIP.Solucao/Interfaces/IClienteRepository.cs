namespace SOLID.DIP.Solucao.Interfaces
{
    public interface IClienteRepository
    {
        void AdicionarCliente(Cliente cliente);
    }
}