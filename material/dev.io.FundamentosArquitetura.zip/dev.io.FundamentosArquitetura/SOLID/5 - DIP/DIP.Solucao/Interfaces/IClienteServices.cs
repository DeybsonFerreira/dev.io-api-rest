namespace SOLID.DIP.Solucao.Interfaces
{
    public interface IClienteServices
    {
        string AdicionarCliente(Cliente cliente);
    }
}