﻿namespace SOLID.OCP.Violacao
{
    public enum TipoConta
    {
        Corrente,
        Poupanca
    }
}